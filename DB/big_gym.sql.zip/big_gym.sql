-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mag 30, 2015 alle 15:11
-- Versione del server: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `big_gym`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `award`
--

CREATE TABLE IF NOT EXISTS `award` (
  `idPremi` int(11) NOT NULL,
  `descrizinePremio` varchar(500) NOT NULL,
  `titolo` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `award`
--

INSERT INTO `award` (`idPremi`, `descrizinePremio`, `titolo`) VALUES
(1, 'Dopo aver lavorato tanto e bene con i clienti, è stato assegnato il premio <b>Best Customer Trainer</b> del mese a ', 'Miglior istruttore per la rivista NoPainNoGain'),
(2, 'Dopo aver lavorato tanto e bene con i clienti, è stato conferito il premio <b>Best Customer Trainer</b> del mese a ', 'Best Customer Trainer');

-- --------------------------------------------------------

--
-- Struttura della tabella `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL,
  `nomeCat` varchar(25) NOT NULL,
  `descrizioneCat` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `category`
--

INSERT INTO `category` (`id`, `nomeCat`, `descrizioneCat`) VALUES
(0, 'Attività di tonificazione', 'Costituiti da parte di lavoro aerobico a tempo di musica e in parte da lavoro di tonificazione adatti a chi...'),
(1, 'Corpo e Mente', 'Questi corsi mirano al miglioramento dell''equilibrio, della mobilità e della postura. La ricerca del benessere psicofisico e la consapevolezza corporea sono le caratteristiche principali di queste attività'),
(2, 'Cardio', 'Corso basato sull''attività cardiovascolare e sulla tonificazione...'),
(3, 'Funzionali', 'Sistema di allenamento innovativo che migliora le performance dell''individuo, predisponendo il corpo a svolgere più efficacemente le attività quotidiane o atletiche attraverso esercizi che...'),
(4, 'Condizionamento', 'Il condizionamento muscolare è la capacità di allenare i propri muscoli ad un grado di contrazione diversa da quella normale, ottenendo...'),
(5, 'Acquafitness', 'Fitness in acqua con musica e supporti didattici.');

-- --------------------------------------------------------

--
-- Struttura della tabella `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `nome` varchar(20) NOT NULL,
  `descrizione` varchar(500) NOT NULL,
  `target` varchar(500) NOT NULL,
  `livello` int(11) NOT NULL,
  `categoria` int(11) NOT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL,
  `istruttore` int(11) NOT NULL,
  `istruttore2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `course`
--

INSERT INTO `course` (`nome`, `descrizione`, `target`, `livello`, `categoria`, `img1`, `img2`, `img3`, `istruttore`, `istruttore2`) VALUES
('Boxe Up', 'Boxe Up è un mix di tutto quello che il nostro istinto o stato d''animo vuole sfogare al sacco: non c’è contatto fisico, non c''è gara e non ci sono vincitori o sconfitti. È un corso di fitness studiato per unire la musica alle tecniche degli sport da combattimento e delle arti marziali, il tutto di fronte a un sacco.', 'Alcuni dei benefici che si possono ottenere con la pratica costante sono: l’aumento della forza e della flessibilità muscolare, decompressione della colonna e delle articolazioni, aumento della mobilità, miglioramento della circolazione sanguigna e linfatica, maggior agilità.flessibilità muscolare, decompressione della colonna e delle articolazioni, aumento della mobili', 0, 2, './img/Box Up1.jpg', './img/Box Up2.jpg', NULL, 2, 0),
('Hydrobike', 'L'' idrobike consiste nella pratica dello spinning in piscina: la bicicletta che si utilizza è una speciale bicicletta da spinning in acciaio, concepita per sfruttare e beneficiare al massimo della resistenza dell'' acqua. Non è necessario saper nuotare per frequentare un corso di hydrobike: l'' acqua infatti raggiunge l'' altezza della vita, spalle e testa rimagono fuori, solo le ginocchia restano sempre sommerse durante gli esercizi.', 'La pratica dell'' hydrobike è l'' ideale per chi presenta problemi di sovrappeso e di ritenzione idrica: è un'' attività fisica di tipo aerobico quindi permette un buon consumo di calorie. Inoltre, un buon allenamento agisce positivamente sul sistema cardio-vascolare rinforzando il cuore, la resistenza alla fatica e migliorando la circolazione.', 2, 5, './img/hydrobike.jpg', './img/hydrobike2.jpg', NULL, 8, 0),
('Jazzercise', 'Il programma Jazzercise è stato fondato nel 1969 dalla Jazzercise CEO Judi Sheppard Missett e mescola la danza, l''allenamento della resistenza, pilates, yoga, kickboxing e movimenti in stile latino con la musica popolare.', 'Rassodamento gluteri e miglioramento della tonicità muscolare delle cosce', 0, 0, './img/jazzercise.jpg', './img/jazzercise2.jpg', NULL, 6, 0),
('Pancafit', 'Pancafit è l’unico attrezzo, brevettato in tutto il mondo, capace di riequilibrare la postura con semplicità ed in tempi brevissimi, agendo sulla globalità delle catene muscolari. E’ in grado di ridare libertà e benessere a tutto il corpo attraverso l''allungamento muscolare globale decompensato. Non si tratta di un semplice stretching analitico o classico. E’ un allungamento muscolare fatto in postura corretta ed utilizza tecniche respiratorie per sbloccare il diaframma', 'Aiuta a migliorare la postura e la condizione fisica grazie alla sua azione sulle tensioni e sulle rigidità muscolari. Inoltre si agisce su tutti gli apparati che hanno relazione con la postura: articolazione temporo-mandibolare e denti, occhi e funzione visiva, sistema cutaneo e cicatrici reattive, sistema podalico e patologie del piede', 1, 3, './img/panca fit.jpg', './img/panca fit2.jpg', NULL, 1, 0),
('Sweeng', 'Il termine SweenG è un gioco parole: unisce la dolcezza “sweet” al divertimento “swing” (dondolare).\r\nLo SweenG nasce dall''unione di due differenti realtà: quella del “controllo” caratteristica della tecnica\r\nPilates con quella dell''allenamento sportivo.', 'Alcuni dei benefici che si possono ottenere con la pratica costante sono: l’aumento della forza e della flessibilità muscolare, decompressione della colonna e delle articolazioni, aumento della mobilità, miglioramento della circolazione sanguigna e linfatica, maggior agilità.', 0, 3, './img/sweeng1.jpg', './img/sweeng2.jpg', './img/sweeng3.jpg', 1, 6),
('Tai Chi', 'La boxe della suprema polarità (t''ai chi ch''uan) è anche abbreviato in Taiji o Tai Chi; stile interno delle arti marziali cinesi nato come tecnica di combattimento, è oggi conosciuto in occidente soprattutto come ginnastica e come tecnica di medicina preventiva.', 'Una delle caratteristiche che ha dato estrema notorietà al Taijiquan è la sua utilità per la salute; riduzione del colesterolo, il miglioramento della cordinazione e un miglioramento delle funzionalità fisiologiche', 2, 1, './img/Tai Chi.jpg', './img/Tai Chi2.jpg', NULL, 5, 0),
('V-Gravity Group', 'Gravity Training System, o più semplicemente GTS, è un metodo di allenamento da effettuarsi per mezzo di un attrezzo dal medesimo nome e che permette di potenziare tutti i distretti muscolari sfruttando in maniera amplificata l’effetto della forza di gravità sul corpo umano.\r\nNato all’inizio del 2000 a San Diego, in California.', 'Questo attrezzo consente infatti di esercitarsi sfruttando circa 150 posizioni diverse, con un conseguente beneficio a livello psico-fisico. È adatto a tutte quelle persone che cercano il massimo dall’allenamento con un impegno di tempo ridotto', 0, 0, './img/v_gravity.jpg', './img/v_gravity2.jpg', NULL, 7, 0),
('V-Jump Conditioning', 'V-Jump Conditioning: Lavoro che combina la resistenza cardiovascolare a quella muscolare su di un ”Trampolino elastico”. Allenamento divertente, di grande intensità e dinamicità.', 'Rassodamento glutei e miglioramento della tonicità muscolare delle cosce', 1, 4, './img/V-Jump1.jpg', './img/V-Jump2.jpg', NULL, 4, 0),
('V-Step Tone', 'Lo Step tone consiste in un allenamento aerobico, nato in America, che utilizza una piattaforma dalla quale\r\nsi sale e si scende. Infatti, lo Step tone è una piattaforma larga circa 40 cm. per un metro di lunghezza. La\r\nlezione di Step tone, (traduzione inglese di gradino), prevede una serie di esercizi dinamici di salita e\r\ndiscesa dalla piattaforma seguendo un ritmo costante scandito dalla musica', 'Aumenta le capacità cardiocircolatorie e respiratorie, offre maggiori benefici muscolari, tonifica al ritmo di musica in particolare gambe e glutei e sviluppa resistenza muscolare grazie ai movimenti continui', 1, 4, './img/step e tone.jpg', './img/step e tone2.jpg', NULL, 4, 0),
('Zumba', 'Zumba è una lezione di fitness musicale di gruppo che utilizza i ritmi e i movimenti della musica afro-caraibica, mixati con i movimenti tradizionali dell''aerobica. Fu creata dal ballerino e coreografo Alberto "Beto" Perez  alla fine degli anni novanta in Colombia.', 'Ha come obiettivo principale creare un alto consumo calorico grazie alla sua intensità variabile. Inoltre le musiche e le coreografie hanno lo scopo principale di divertire il praticante in modo da fargli dimenticare lo sforzo fisico con conseguente alto consumo calorico.', 2, 2, './img/Zumba1.jpg', './img/Zumba2.jpg', NULL, 3, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `instructor`
--

CREATE TABLE IF NOT EXISTS `instructor` (
  `id_istruttore` int(11) NOT NULL,
  `nomeIstruttore` varchar(20) NOT NULL,
  `categoria` int(11) NOT NULL,
  `corso1` varchar(20) DEFAULT NULL,
  `corso2` varchar(20) DEFAULT NULL,
  `img` varchar(50) NOT NULL,
  `eta` int(11) NOT NULL,
  `altezza` int(11) NOT NULL,
  `id_premi` int(11) DEFAULT NULL,
  `storia` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `instructor`
--

INSERT INTO `instructor` (`id_istruttore`, `nomeIstruttore`, `categoria`, `corso1`, `corso2`, `img`, `eta`, `altezza`, `id_premi`, `storia`) VALUES
(1, 'Stefano Campari', 3, 'Pancafit', 'Sweeng', './img/stefano_campari.jpg', 30, 175, 1, ''),
(2, 'Giorgio Castoldi', 2, 'Boxe Up', NULL, './img/giorgio_castoldi.jpg', 32, 180, NULL, NULL),
(3, 'Benedetta Roncalli', 2, 'Zumba', NULL, './img/benedetta_roncalli.jpg', 28, 167, 2, NULL),
(4, 'Giampaolo Gambi', 4, 'V-Jump Conditioning', 'V-Step Tone', './img/giampaolo_gambi.jpg', 28, 172, NULL, NULL),
(5, 'Maurizio Carugati', 1, 'Tai Chi', NULL, './img/maurizio_carugati.jpg', 45, 176, 2, NULL),
(6, 'Fanni Fidenzio', 0, 'Jazzercise', 'Sweeng', './img/fanni_fidenzio.jpg', 46, 170, 2, NULL),
(7, 'Erica Abate', 0, 'V-Gravity Group', NULL, './img/erika_abate.jpg', 32, 170, NULL, NULL),
(8, 'Marco Bancone', 5, 'Hydrobike', NULL, './img/marco_bancone.jpg', 39, 170, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `award`
--
ALTER TABLE `award`
  ADD PRIMARY KEY (`idPremi`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`nome`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`id_istruttore`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
