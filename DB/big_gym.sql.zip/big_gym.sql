-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mag 28, 2015 alle 10:25
-- Versione del server: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `big_gym`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL,
  `nomeCat` varchar(25) NOT NULL,
  `descrizione` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `category`
--

INSERT INTO `category` (`id`, `nomeCat`, `descrizione`) VALUES
(0, 'Attività di tonificazione', 'Costituiti da parte di lavoro aerobico a tempo di musica e in parte da lavoro di tonificazione adatti a chi...'),
(1, 'Corpo e Mente', 'Questi corsi mirano al miglioramento dell''equilibrio, della mobilità e della postura. La ricerca del benessere psicofisico e la consapevolezza corporea sono le caratteristiche principali di queste attività'),
(2, 'Cardio', 'Corso basato sull''attività cardiovascolare e sulla tonificazione...'),
(3, 'Funzionali', 'Sistema di allenamento innovativo che migliora le performance dell''individuo, predisponendo il corpo a svolgere più efficacemente le attività quotidiane o atletiche attraverso esercizi che...'),
(4, 'Condizionamento', 'Il condizionamento muscolare è la capacità di allenare i propri muscoli ad un grado di contrazione diversa da quella normale, ottenendo...'),
(5, 'Acquafitness', 'Fitness in acqua con musica e supporti didattici.');

-- --------------------------------------------------------

--
-- Struttura della tabella `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `nome` varchar(20) NOT NULL,
  `descrizione` varchar(500) NOT NULL,
  `livello` int(11) NOT NULL,
  `categoria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `course`
--

INSERT INTO `course` (`nome`, `descrizione`, `livello`, `categoria`) VALUES
('Boxe Up', 'Boxe Up è un mix di tutto quello che il nostro istinto o stato d''animo vuole sfogare al sacco: non c’è contatto fisico, non c''è gara e non ci sono vincitori o sconfitti. È un corso di fitness studiato per unire la musica alle tecniche degli sport da combattimento e delle arti marziali, il tutto di fronte a un sacco.', 0, 2),
('Hydrobike', 'L'' idrobike consiste nella pratica dello spinning in piscina: la bicicletta che si utilizza è una speciale bicicletta da spinning in acciaio, concepita per sfruttare e beneficiare al massimo della resistenza dell'' acqua. Non è necessario saper nuotare per frequentare un corso di hydrobike: l'' acqua infatti raggiunge l'' altezza della vita, spalle e testa rimagono fuori, solo le ginocchia restano sempre sommerse durante gli esercizi.', 2, 5),
('Jazzercise', 'Il programma Jazzercise è stato fondato nel 1969 dalla Jazzercise CEO Judi Sheppard Missett e mescola la danza, l''allenamento della resistenza, pilates, yoga, kickboxing e movimenti in stile latino con la musica popolare.', 0, 0),
('Pancafit', 'Pancafit è l’unico attrezzo, brevettato in tutto il mondo, capace di riequilibrare la postura con semplicità ed in tempi brevissimi, agendo sulla globalità delle catene muscolari. E’ in grado di ridare libertà e benessere a tutto il corpo attraverso l''allungamento muscolare globale decompensato. Non si tratta di un semplice stretching analitico o classico. E’ un allungamento muscolare fatto in postura corretta ed utilizza tecniche respiratorie per sbloccare il diaframma', 1, 3),
('Sweeng', 'Il termine SweenG è un gioco parole: unisce la dolcezza “sweet” al divertimento “swing” (dondolare).\r\nLo SweenG nasce dall''unione di due differenti realtà: quella del “controllo” caratteristica della tecnica\r\nPilates con quella dell''allenamento sportivo.', 0, 3),
('Tai Chi', 'La boxe della suprema polarità (t''ai chi ch''uan) è anche abbreviato in Taiji o Tai Chi; stile interno delle arti marziali cinesi nato come tecnica di combattimento, è oggi conosciuto in occidente soprattutto come ginnastica e come tecnica di medicina preventiva.', 2, 1),
('V-Gravity Group', 'Gravity Training System, o più semplicemente GTS, è un metodo di allenamento da effettuarsi per mezzo di un attrezzo dal medesimo nome e che permette di potenziare tutti i distretti muscolari sfruttando in maniera amplificata l’effetto della forza di gravità sul corpo umano.\r\nNato all’inizio del 2000 a San Diego, in California.', 0, 0),
('V-Jump Conditioning', 'V-Jump Conditioning: Lavoro che combina la resistenza cardiovascolare a quella muscolare su di un ”Trampolino elastico”. Allenamento divertente, di grande intensità e dinamicità.', 1, 4),
('V-Step e Tone', 'Lo Step tone consiste in un allenamento aerobico, nato in America, che utilizza una piattaforma dalla quale\r\nsi sale e si scende. Infatti, lo Step tone è una piattaforma larga circa 40 cm. per un metro di lunghezza. La\r\nlezione di Step tone, (traduzione inglese di gradino), prevede una serie di esercizi dinamici di salita e\r\ndiscesa dalla piattaforma seguendo un ritmo costante scandito dalla musica', 1, 4),
('Zumba', 'Zumba è una lezione di fitness musicale di gruppo che utilizza i ritmi e i movimenti della musica afro-caraibica, mixati con i movimenti tradizionali dell''aerobica. Fu creata dal ballerino e coreografo Alberto "Beto" Perez  alla fine degli anni novanta in Colombia.', 2, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`nome`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
