-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mag 25, 2015 alle 10:46
-- Versione del server: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `big_gym`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `descrizione` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `category`
--

INSERT INTO `category` (`id`, `nome`, `descrizione`) VALUES
(0, 'Attività di tonifica', 'Costituiti da parte di lavoro aerobico a tempo di musica e in parte da lavoro di tonificazione adatti a chi...'),
(1, 'Corpo e Mente', 'Questi corsi mirano al miglioramento dell''equilibrio, della mobilità e della postura. La ricerca del benessere psicofisico e la consapevolezza corporea sono le caratteristiche principali di queste attività'),
(2, 'Cardio', 'Corso basato sull''attività cardiovascolare e sulla tonificazione...'),
(3, 'Funzionali', 'Sistema di allenamento innovativo che migliora le performance dell''individuo, predisponendo il corpo a svolgere più efficacemente le attività quotidiane o atletiche attraverso esercizi che...'),
(4, 'Condizionamento', 'Il condizionamento muscolare è la capacità di allenare i propri muscoli ad un grado di contrazione diversa da quella normale, ottenendo...'),
(5, 'Acquafitness', 'Fitness in acqua con musica e supporti didattici.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
